from flask import Flask, url_for, render_template

app = Flask(__name__)
app.config['SECRET_KEY'] = 'TOP_SECRET'


@app.route('/')
def base():
    title = 'Марс'
    return render_template('base.html', title=title)


@app.route('/<title>')
@app.route('/index/<title>')
def index(title):
    return render_template('base.html', title=title)


@app.route('/training/<prof>')
def training(prof):
    title = 'Карта'
    if 'инженер' in prof.lower() or 'строитель' in prof.lower():
        prof = 'Инженерные тренажеры'
        img_src = '/static/img/spaceship_es.png'
    else:
        prof = 'Научные симуляторы'
        img_src = '/static/img/spaceship_ss.png'
    return render_template('training.html', title=title, prof=prof, img_src=img_src)


@app.route('/list_prof/<list_type>')
def list_prof(list_type):
    prof_list = ['Инженер-исследователь', 'Пилот', 'Строитель', 'Экзобиолог', 'Врач']
    if list_type == 'ol':
        for n in range(len(prof_list)):
            prof_list[n] = f'{n + 1}. ' + prof_list[n]
    elif list_type == 'ul':
        for n in range(len(prof_list)):
            prof_list[n] = '• ' + prof_list[n]
    else:
        return render_template('list_prof_error.html')
    return render_template('list_prof.html', prof_list=prof_list)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)
